const PAYPAL_API_BASE =
  process.env.PAYPAL_API_BASE || "https://api-m.paypal.com";
const PAYPAL_CLIENT_ID =
  process.env.PAYPAL_CLIENT_ID || process.env.NEW_PAYPAL_CLIENT_ID || "";
const PAYPAL_SECRET = process.env.PAYPAL_SECRET || "";

async function getAccessToken(): Promise<string> {
  if (!PAYPAL_CLIENT_ID || !PAYPAL_SECRET) {
    throw new Error("PayPal credentials are not configured on the server.");
  }
  const auth = Buffer.from(`${PAYPAL_CLIENT_ID}:${PAYPAL_SECRET}`).toString(
    "base64",
  );
  const res = await fetch(`${PAYPAL_API_BASE}/v1/oauth2/token`, {
    method: "POST",
    headers: {
      Authorization: `Basic ${auth}`,
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: "grant_type=client_credentials",
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`PayPal auth failed (${res.status}): ${text}`);
  }
  const data = (await res.json()) as { access_token?: string };
  if (!data.access_token) throw new Error("PayPal auth missing access_token");
  return data.access_token;
}

const json = (status: number, body: unknown) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { "content-type": "application/json" },
  });

export default async (req: Request): Promise<Response> => {
  if (req.method !== "POST") return json(405, { error: "Method not allowed" });

  try {
    const body = (await req.json().catch(() => ({}))) as { orderId?: string };
    const orderId = String(body.orderId || "");
    if (!orderId) return json(400, { error: "orderId is required" });

    const token = await getAccessToken();
    const capRes = await fetch(
      `${PAYPAL_API_BASE}/v2/checkout/orders/${encodeURIComponent(orderId)}/capture`,
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      },
    );

    const data = (await capRes.json()) as {
      status?: string;
      id?: string;
      purchase_units?: Array<{
        payments?: {
          captures?: Array<{
            id?: string;
            status?: string;
            amount?: { value?: string; currency_code?: string };
          }>;
        };
      }>;
    };

    if (!capRes.ok) {
      console.error("PayPal capture failed", capRes.status, data);
      return json(502, {
        error: "Failed to capture PayPal order",
        details: data,
      });
    }

    const capture = data.purchase_units?.[0]?.payments?.captures?.[0];
    return json(200, {
      status: data.status,
      orderId: data.id,
      captureId: capture?.id,
      captureStatus: capture?.status,
      amount: capture?.amount,
    });
  } catch (err) {
    console.error("capture-order error", err);
    return json(500, { error: "Server error capturing order" });
  }
};

export const config = { path: "/api/paypal/capture-order" };
