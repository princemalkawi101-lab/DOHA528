const PAYPAL_CLIENT_ID =
  process.env.PAYPAL_CLIENT_ID ||
  process.env.NEW_PAYPAL_CLIENT_ID ||
  process.env.VITE_PAYPAL_CLIENT_ID ||
  "";

const JOD_TO_USD = Number(process.env.JOD_TO_USD || "1.41");
const CURRENCY = process.env.PAYPAL_CURRENCY || "USD";

export default async (_req: Request): Promise<Response> => {
  if (!PAYPAL_CLIENT_ID) {
    return new Response(JSON.stringify({ error: "PayPal not configured" }), {
      status: 500,
      headers: { "content-type": "application/json" },
    });
  }
  return new Response(
    JSON.stringify({
      clientId: PAYPAL_CLIENT_ID,
      currency: CURRENCY,
      jodToUsd: JOD_TO_USD,
    }),
    { status: 200, headers: { "content-type": "application/json" } },
  );
};

export const config = { path: "/api/paypal/config" };
