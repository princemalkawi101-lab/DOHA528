const PAYPAL_API_BASE =
  process.env.PAYPAL_API_BASE || "https://api-m.paypal.com";
const PAYPAL_CLIENT_ID =
  process.env.PAYPAL_CLIENT_ID || process.env.NEW_PAYPAL_CLIENT_ID || "";
const PAYPAL_SECRET = process.env.PAYPAL_SECRET || "";
const JOD_TO_USD = Number(process.env.JOD_TO_USD || "1.41");
const CURRENCY = process.env.PAYPAL_CURRENCY || "USD";

type CartLine = {
  titleEn?: string;
  titleAr?: string;
  nameKey?: string;
  jod: number;
  qty: number;
};

function round2(n: number): string {
  return (Math.round(n * 100) / 100).toFixed(2);
}

async function getAccessToken(): Promise<string> {
  if (!PAYPAL_CLIENT_ID || !PAYPAL_SECRET) {
    throw new Error("PayPal credentials are not configured on the server.");
  }
  const auth = Buffer.from(`${PAYPAL_CLIENT_ID}:${PAYPAL_SECRET}`).toString(
    "base64",
  );
  const res = await fetch(`${PAYPAL_API_BASE}/v1/oauth2/token`, {
    method: "POST",
    headers: {
      Authorization: `Basic ${auth}`,
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: "grant_type=client_credentials",
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`PayPal auth failed (${res.status}): ${text}`);
  }
  const data = (await res.json()) as { access_token?: string };
  if (!data.access_token) throw new Error("PayPal auth missing access_token");
  return data.access_token;
}

const json = (status: number, body: unknown) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { "content-type": "application/json" },
  });

export default async (req: Request): Promise<Response> => {
  if (req.method !== "POST") return json(405, { error: "Method not allowed" });

  try {
    const body = (await req.json().catch(() => ({}))) as { cart?: CartLine[] };
    const cart = Array.isArray(body.cart) ? body.cart : [];
    if (cart.length === 0) return json(400, { error: "Cart is empty" });

    let totalJod = 0;
    for (const item of cart) {
      const jod = Number(item.jod);
      const qty = Number(item.qty);
      if (!isFinite(jod) || jod < 0 || !isFinite(qty) || qty <= 0) {
        return json(400, { error: "Invalid cart item" });
      }
      totalJod += jod * qty;
    }
    if (totalJod <= 0)
      return json(400, { error: "Cart total must be greater than zero" });

    const totalUsd = round2(totalJod * JOD_TO_USD);

    const items = cart.map((item) => {
      const name = (item.titleEn || item.titleAr || item.nameKey || "Item")
        .toString()
        .slice(0, 127);
      const unitUsd = round2(Number(item.jod) * JOD_TO_USD);
      return {
        name,
        quantity: String(item.qty),
        unit_amount: { currency_code: CURRENCY, value: unitUsd },
      };
    });

    const itemTotal = round2(
      cart.reduce(
        (sum, i) =>
          sum + Number(round2(Number(i.jod) * JOD_TO_USD)) * Number(i.qty),
        0,
      ),
    );

    const token = await getAccessToken();
    const orderRes = await fetch(`${PAYPAL_API_BASE}/v2/checkout/orders`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        intent: "CAPTURE",
        purchase_units: [
          {
            amount: {
              currency_code: CURRENCY,
              value: itemTotal,
              breakdown: {
                item_total: { currency_code: CURRENCY, value: itemTotal },
              },
            },
            items,
            description: `Doha Healing order (${totalJod.toFixed(2)} JOD ~ ${totalUsd} USD)`,
          },
        ],
      }),
    });

    if (!orderRes.ok) {
      const text = await orderRes.text();
      console.error("PayPal create order failed", orderRes.status, text);
      return json(502, { error: "Failed to create PayPal order" });
    }
    const data = (await orderRes.json()) as { id?: string };
    if (!data.id) return json(502, { error: "PayPal response missing id" });
    return json(200, {
      id: data.id,
      totalUsd,
      totalJod: round2(totalJod),
    });
  } catch (err) {
    console.error("create-order error", err);
    return json(500, { error: "Server error creating order" });
  }
};

export const config = { path: "/api/paypal/create-order" };
